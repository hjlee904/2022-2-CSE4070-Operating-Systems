#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>
#include "list.h"
#include "hash.h"
#include "bitmap.h"
#define MAX 20

struct list list_[MAX];
struct list* l_pointer;
struct list_elem* l_elem;
struct list_item* l_item;

struct hash hash_[MAX];
struct hash* h_pointer;
struct hash_elem* h_elem;
struct hash_item* h_item;

struct bitmap* bitmap_[MAX];
struct bitmap* b_pointer;

int l_idx = 0, h_idx = 0, b_idx = 0;
int b_idx_arr[MAX] = { 0 };
int b_size = 0;
int h_idx2 = 0;

char* cut_tok(char* tok);

bool l_less_func(const struct list_elem* a, const struct list_elem* b, void* aux);
bool h_less_func(const struct hash_elem* a, const struct hash_elem* b, void* aux);
unsigned int h_hash_func(const struct hash_elem* a, void* aux);

struct list* find_list(char* name);
struct hash* find_hash(char* name);
struct bitmap* find_bitmap(char* name);

void h_ac(struct hash_elem* a, void* aux);
void h_square(struct hash_elem* a, void* aux);
void h_triple(struct hash_elem* a, void* aux);

int main() {
	char str[100];

	// quit�� �ԷµǱ� ������ �ݺ�
	while (1) {
		fgets(str, sizeof(str), stdin);

		// quit�� �ԷµǸ� ����
		if (!strcmp(str, "quit\n")) {
			break;
		}

		// ���� �Է��� " "�� �ڸ���, tok�� ����
		char* tok = strtok(str, " ");

		// 1. �Է����� create�� ���� ��� (create: ���� ����)
		if (!strcmp(tok, "create")) {
			
			// tok�� ���� ��ū ����
			tok = strtok(NULL, " ");

			// 1-1. �Է����� create list�� ���� ���
			if (!strcmp(tok, "list")) {
				l_pointer = &list_[l_idx];
				list_init(l_pointer);
				
				// tok�� list �̸� ���� �� list_name�� �̸� ����
				tok = strtok(NULL, " ");
				strcpy(l_pointer->list_name, cut_tok(tok));

				l_idx++;
			}

			// 1-2. �Է����� create hashtable�� ���� ���
			else if (!strcmp(tok, "hashtable")) {
				h_pointer = &hash_[h_idx];
				
				hash_init(h_pointer, h_hash_func, h_less_func, NULL);

				// buckets�� list ����
				for (int i = 0; i < h_pointer->bucket_cnt; i++) {
					list_init(&h_pointer->buckets[i]);
				}

				// tok�� hashtable �̸� ���� �� hash_name�� �̸� ����
				tok = strtok(NULL, " ");
				strcpy(h_pointer->hash_name, cut_tok(tok));

				h_idx++;
			}

			// 1-3. �Է����� create bitmap�� ���� ���
			else if (!strcmp(tok, "bitmap")) {
				char bitmap_name_temp[20];
				int i = 0;

				for (i = 0; i < MAX; i++) {
					if (b_idx_arr[i] == 0) break;
				}

				b_idx_arr[i] = 1;

				// tok�� bitmap �̸� ����
				tok = strtok(NULL, " ");
				strcpy(bitmap_name_temp, cut_tok(tok));

				// tok�� bitmap�� size�� ����
				tok = strtok(NULL, " ");
				b_size = atoi(tok);

				// bitmap ���� �� bitmap_name�� �̸� ����
				bitmap_[i] = bitmap_create(b_size);
				b_name(bitmap_[i], bitmap_name_temp);
			}

		}

		// 2. �Է����� dumpdata�� ���� ��� (dumpdata: ����Ǿ��ִ� ������ .out ���Ͽ� ���)
		else if (!strcmp(tok, "dumpdata")) {

			// tok�� ���� ��ū ����
			tok = strtok(NULL, " ");
			
			int flag = 0;

			// 2-1. �Է����� dumpdata list#�� ���� ���
			if (strstr(tok, "list") != NULL) {
				l_pointer = find_list(tok);
				l_elem = list_begin(l_pointer);

				while (list_tail(l_pointer) != l_elem) {
					l_item = list_entry(l_elem, struct list_item, elem);
					printf("%d ", l_item->data);
					l_elem = list_next(l_elem);
					flag = 1;
				}
			}

			// 2-2. �Է����� dumpdata hash#�� ���� ���
			else if (strstr(tok, "hash") != NULL) {
				struct hash_iterator h_iterator;
				h_pointer = find_hash(tok);
				hash_first(&h_iterator, h_pointer);

				// dumpdata
				while (hash_next(&h_iterator)) {
					h_item = hash_entry(hash_cur(&h_iterator), struct hash_item, elem);
					printf("%d ", h_item->data);
					flag = 1;
				}
			}

			// 2-3. �Է����� dumpdata bm#�� ���� ���
			else if (strstr(tok, "bm") != NULL) {
				b_pointer = find_bitmap(tok);
				b_dumpdata(b_pointer);
				flag = 1;
			}

			// ������ �ٹٲ�
			if (flag) {
				printf("\n");
			}

		}

		// 3. �Է����� delete�� ���� ��� (delete: ����)
		else if (!strcmp(tok, "delete")) {

			// tok�� ���� ��ū ����
			tok = strtok(NULL, " ");

			// 3-1. �Է����� delete list#�� ���� ���
			if (l_pointer != NULL) {
				l_pointer = find_list(tok);
				l_elem = list_begin(l_pointer);

				while (l_elem != list_tail(l_pointer)) {
					l_item = list_entry(l_elem, struct list_item, elem);
					l_elem = list_next(l_elem);
					
					free(l_item);
				}
				list_init(l_pointer);
			}

			// 3-2. �Է����� delete hash#�� ���� ���
			else if (h_pointer != NULL) {
				h_pointer = find_hash(tok);
				hash_destroy(h_pointer, *h_ac);
				hash_init(&hash_[h_idx2], NULL, NULL, NULL);
			}

			// 3-3. �Է����� delete bm#�� ���� ���
			else if (b_pointer != NULL) {
				b_pointer = find_bitmap(tok);
				bitmap_destroy(b_pointer);
				bitmap_[b_idx] = NULL;
				b_idx_arr[b_idx] = 0;
			}
		}

		// 4. �� �ܿ� list���� �Լ����� ���� ���
		// push_front, push_back, pop_front, pop_back, front, back, insert, insert_ordered. empty, size, max, min, remove, reverse, shuffle, sort, splice, swap, unique
		else if (!strcmp(tok, "list_push_front")) {
			tok = strtok(NULL, " ");
			l_pointer = find_list(tok);

			l_elem = malloc(sizeof(struct list_elem));
			l_item = malloc(sizeof(struct list_item));
			l_item = list_entry(l_elem, struct list_item, elem);

			tok = strtok(NULL, " ");
			l_item->data = atoi(tok);

			list_push_front(l_pointer, l_elem);
		}

		else if (!strcmp(tok, "list_push_back")) {
			tok = strtok(NULL, " ");
			l_pointer = find_list(tok);

			l_elem = malloc(sizeof(struct list_elem));
			l_item = malloc(sizeof(struct list_item));
			l_item = list_entry(l_elem, struct list_item, elem);

			tok = strtok(NULL, " ");
			l_item->data = atoi(tok);

			list_push_back(l_pointer, l_elem);
		}

		else if (!strcmp(tok, "list_pop_front")) {
			tok = strtok(NULL, " ");
			l_pointer = find_list(tok);

			l_elem = list_pop_front(l_pointer);
		}

		else if (!strcmp(tok, "list_pop_back")) {
			tok = strtok(NULL, " ");
			l_pointer = find_list(tok);

			l_elem = list_pop_back(l_pointer);
		}

		else if (!strcmp(tok, "list_front")) {
			tok = strtok(NULL, " ");

			l_elem = list_begin(find_list(tok));
			l_item = list_entry(l_elem, struct list_item, elem);

			printf("%d\n", l_item->data);
		}

		else if (!strcmp(tok, "list_back")) {
			tok = strtok(NULL, " ");

			l_elem = list_rbegin(find_list(tok));
			l_item = list_entry(l_elem, struct list_item, elem);

			printf("%d\n", l_item->data);
		}

		else if (!strcmp(tok, "list_insert")) {
			tok = strtok(NULL, " ");
			l_pointer = find_list(tok);
			
			tok = strtok(NULL, " ");
			int i = atoi(tok); 
			int j = 0;

			l_elem = malloc(sizeof(struct list_elem));
			l_item = malloc(sizeof(struct list_item));
			l_item = list_entry(l_elem, struct list_item, elem);

			tok = strtok(NULL, " ");
			l_item->data = atoi(tok);

			struct list_elem* l_elem_next = list_begin(l_pointer);

			while (j < i) {
				l_elem_next = list_next(l_elem_next);
				j++;
			}
			list_insert(l_elem_next, l_elem);
		}

		else if (!strcmp(tok, "list_insert_ordered")) {
			tok = strtok(NULL, " ");
			l_pointer = find_list(tok);

			l_elem = malloc(sizeof(struct list_elem));
			l_item = malloc(sizeof(struct list_item));
			l_item = list_entry(l_elem, struct list_item, elem);

			tok = strtok(NULL, " ");
			l_item->data = atoi(tok);

			list_insert_ordered(l_pointer, l_elem, *l_less_func, NULL);
		}

		else if (!strcmp(tok, "list_empty")) {
			tok = strtok(NULL, " ");
			l_pointer = find_list(tok);

			if (list_empty(l_pointer)) {
				printf("true\n");
			}
			else printf("false\n");
		}

		else if (!strcmp(tok, "list_size")) {
			tok = strtok(NULL, " ");
			l_pointer = find_list(tok);

			printf("%zu\n", list_size(l_pointer));
		}

		else if (!strcmp(tok, "list_max")) {
			tok = strtok(NULL, " ");
			l_pointer = find_list(tok);

			l_elem = list_max(l_pointer, *l_less_func, NULL);
			l_item = list_entry(l_elem, struct list_item, elem);

			printf("%d\n", l_item->data);
		}

		else if (!strcmp(tok, "list_min")) {
			tok = strtok(NULL, " ");
			l_pointer = find_list(tok);

			l_elem = list_min(l_pointer, *l_less_func, NULL);
			l_item = list_entry(l_elem, struct list_item, elem);

			printf("%d\n", l_item->data);
		}

		else if (!strcmp(tok, "list_remove")) {
			tok = strtok(NULL, " ");
			l_elem = list_begin(find_list(tok));

			tok = strtok(NULL, " ");
			int i = 0;

			while (i < atoi(tok)) {
				l_elem = list_next(l_elem);
				i++;
			}

			list_remove(l_elem);
		}

		else if (!strcmp(tok, "list_reverse")) {
			tok = strtok(NULL, " ");
			l_pointer = find_list(tok);

			list_reverse(l_pointer);
		}

		else if (!strcmp(tok, "list_shuffle")) {
			tok = strtok(NULL, " ");
			l_pointer = find_list(tok);

			list_shuffle(l_pointer);
		}

		else if (!strcmp(tok, "list_sort")) {
			tok = strtok(NULL, " ");
			l_pointer = find_list(tok);

			list_sort(l_pointer, *l_less_func, NULL);
		}
		
		else if (!strcmp(tok, "list_splice")) {
			tok = strtok(NULL, " ");
			struct list* list_1 = find_list(tok);

			tok = strtok(NULL, " ");
			int i = atoi(tok);

			tok = strtok(NULL, " ");
			struct list* list_2 = find_list(tok);

			tok = strtok(NULL, " ");
			int j = atoi(tok);

			tok = strtok(NULL, " ");
			int k = atoi(tok);

			struct list_elem* l_before= list_begin(list_1);
			struct list_elem* l_first = list_begin(list_2);
			struct list_elem* l_last = list_begin(list_2);

			int m = 0;
			while (m < i) {
				l_before = list_next(l_before);
				m++;
			}

			m = 0;
			while (m < j) {
				l_first = list_next(l_first);
				m++;
			}

			m = 0;
			while (m < k) {
				l_last = list_next(l_last);
				m++;
			}

			list_splice(l_before, l_first, l_last);
		}

		else if (!strcmp(tok, "list_swap")) {
			tok = strtok(NULL, " ");
			l_pointer = find_list(tok);

			tok = strtok(NULL, " ");
			int i = atoi(tok);

			tok = strtok(NULL, " ");
			int j = atoi(tok);

			struct list_elem* list_1 = list_begin(l_pointer);
			struct list_elem* list_2 = list_begin(l_pointer);

			int m = 0;
			while (m < i) {
				list_1 = list_next(list_1);
				m++;
			}

			m = 0;
			while (m < j) {
				list_2 = list_next(list_2);
				m++;
			}

			list_swap(list_1, list_2);
		}

		else if (!strcmp(tok, "list_unique")) {
			tok = strtok(NULL, " ");
			l_pointer = find_list(tok);

			tok = strtok(NULL, " ");
			struct list* l_duplicate;

			if (tok != NULL) {
				l_duplicate = find_list(tok);
			}
			else {
				l_duplicate = malloc(sizeof(struct list));
				list_init(l_duplicate);
			}

			list_unique(l_pointer, l_duplicate, *l_less_func, NULL);
		}

		// 5. �� �ܿ� hash���� �Լ����� ���� ���
		// insert, delete, apply, empty, size, clear, find, replace
		else if (!strcmp(tok, "hash_insert")) {
			tok = strtok(NULL, " ");
			h_pointer = find_hash(tok);

			h_elem = malloc(sizeof(struct hash_elem));
			h_item = malloc(sizeof(struct hash_item));
			h_item = hash_entry(h_elem, struct hash_item, elem);

			tok = strtok(NULL, " ");
			h_item->data = atoi(tok);

			hash_insert(h_pointer, h_elem);
		}

		else if (!strcmp(tok, "hash_delete")) {
			tok = strtok(NULL, " ");
			h_pointer = find_hash(tok);

			h_elem = malloc(sizeof(struct hash_elem));
			h_item = malloc(sizeof(struct hash_item));
			h_item = hash_entry(h_elem, struct hash_item, elem);

			tok = strtok(NULL, " ");
			h_item->data = atoi(tok);

			hash_delete(h_pointer, h_elem);
		}

		else if (!strcmp(tok, "hash_apply")) {
			tok = strtok(NULL, " ");
			h_pointer = find_hash(tok);

			tok = strtok(NULL, "\n");
			if (!strcmp(tok, "square")) {
				hash_apply(h_pointer, *h_square);
			}
			else if (!strcmp(tok, "triple")) {
				hash_apply(h_pointer, *h_triple);
			}
		}

		else if (!strcmp(tok, "hash_empty")) {
			tok = strtok(NULL, " ");
			h_pointer = find_hash(tok);

			if (hash_empty(h_pointer)) {
				printf("true\n");
			}
			else printf("false\n");
		}

		else if (!strcmp(tok, "hash_size")) {
			tok = strtok(NULL, " ");
			h_pointer = find_hash(tok);

			printf("%zu\n", hash_size(h_pointer));
		}

		else if (!strcmp(tok, "hash_clear")) {
			tok = strtok(NULL, " ");
			h_pointer = find_hash(tok);

			hash_clear(h_pointer, *h_ac);
		}

		else if (!strcmp(tok, "hash_find")) {
			tok = strtok(NULL, " ");
			h_pointer = find_hash(tok);

			h_elem = malloc(sizeof(struct hash_elem));
			h_item = malloc(sizeof(struct hash_item));
			h_item = hash_entry(h_elem, struct hash_item, elem);

			tok = strtok(NULL, " ");
			h_item->data = atoi(tok);

			if (hash_find(h_pointer, h_elem)) {
				printf("%d\n", h_item->data);
			}
		}

		else if (!strcmp(tok, "hash_replace")) {
			tok = strtok(NULL, " ");
			h_pointer = find_hash(tok);

			h_elem = malloc(sizeof(struct hash_elem));
			h_item = malloc(sizeof(struct hash_item));
			h_item = hash_entry(h_elem, struct hash_item, elem);

			tok = strtok(NULL, " ");
			h_item->data = atoi(tok);

			hash_replace(h_pointer, h_elem);
		}

		// 6. �� �ܿ� bitmap���� �Լ����� ���� ���
		// mark, all, any, contains, count, dump, expand, flip, none, reset, scan, scan_and_flip, set, set_multiple, set_all, size, test
		else if (!strcmp(tok, "bitmap_mark")) {
			tok = strtok(NULL, " ");
			b_pointer = find_bitmap(tok);

			tok = strtok(NULL, " ");
			int i = atoi(tok);

			bitmap_mark(b_pointer, i);
		}

		else if (!strcmp(tok, "bitmap_all")) {
			tok = strtok(NULL, " ");
			b_pointer = find_bitmap(tok);

			tok = strtok(NULL, " ");
			int i = atoi(tok);

			tok = strtok(NULL, " ");
			int j = atoi(tok);

			if (bitmap_all(b_pointer, i, j)) {
				printf("true\n");
			}
			else printf("false\n");
		}

		else if (!strcmp(tok, "bitmap_any")) {
			tok = strtok(NULL, " ");
			b_pointer = find_bitmap(tok);

			tok = strtok(NULL, " ");
			int i = atoi(tok);

			tok = strtok(NULL, " ");
			int j = atoi(tok);

			if (bitmap_any(b_pointer, i, j)) {
				printf("true\n");
			}
			else printf("false\n");
		}

		else if (!strcmp(tok, "bitmap_contains")) {
			tok = strtok(NULL, " ");
			b_pointer = find_bitmap(tok);

			tok = strtok(NULL, " ");
			int i = atoi(tok);

			tok = strtok(NULL, " ");
			int j = atoi(tok);

			tok = strtok(NULL, " ");
			bool k;
			
			if (!strcmp(cut_tok(tok), "true")) {
				k = true;
			}
			else k = false;

			if (bitmap_contains(b_pointer, i, j, k)) {
				printf("true\n");
			}
			else printf("false\n");
		}

		else if (!strcmp(tok, "bitmap_count")) {
			tok = strtok(NULL, " ");
			b_pointer = find_bitmap(tok);

			tok = strtok(NULL, " ");
			int i = atoi(tok);

			tok = strtok(NULL, " ");
			int j = atoi(tok);

			tok = strtok(NULL, " ");
			bool k;
			
			if (!strcmp(cut_tok(tok), "true")) {
				k = true;
			}
			else k = false;

			printf("%zu\n", bitmap_count(b_pointer, i, j, k));
		}

		else if (!strcmp(tok, "bitmap_dump")) {
			tok = strtok(NULL, " ");
			b_pointer = find_bitmap(tok);

			bitmap_dump(b_pointer);
		}

		else if (!strcmp(tok, "bitmap_expand")) {
			tok = strtok(NULL, " ");
			b_pointer = find_bitmap(tok);

			tok = strtok(NULL, " ");
			int i = atoi(tok);

			bitmap_expand(b_pointer, i);
		}

		else if (!strcmp(tok, "bitmap_flip")) {
			tok = strtok(NULL, " ");
			b_pointer = find_bitmap(tok);

			tok = strtok(NULL, " ");
			int i = atoi(tok);

			bitmap_flip(b_pointer, i);
		}

		else if (!strcmp(tok, "bitmap_none")) {
			tok = strtok(NULL, " ");
			b_pointer = find_bitmap(tok);

			tok = strtok(NULL, " ");
			int i = atoi(tok);

			tok = strtok(NULL, " ");
			int j = atoi(tok);

			if (bitmap_none(b_pointer, i, j)) {
				printf("true\n");
			}
			else printf("false\n");
		}

		else if (!strcmp(tok, "bitmap_reset")) {
			tok = strtok(NULL, " ");
			b_pointer = find_bitmap(tok);

			tok = strtok(NULL, " ");
			int i = atoi(tok);

			bitmap_reset(b_pointer, i);
		}

		else if (!strcmp(tok, "bitmap_scan")) {
			tok = strtok(NULL, " ");
			b_pointer = find_bitmap(tok);

			tok = strtok(NULL, " ");
			int i = atoi(tok);

			tok = strtok(NULL, " ");
			int j = atoi(tok);

			tok = strtok(NULL, " ");
			bool k;
			
			if (!strcmp(cut_tok(tok), "true")) {
				k = true;
			}
			else k = false;

			size_t m = bitmap_scan(b_pointer, i, j, k);

			printf("%zu\n", m);
		}

		else if (!strcmp(tok, "bitmap_scan_and_flip")) {
			tok = strtok(NULL, " ");
			b_pointer = find_bitmap(tok);

			tok = strtok(NULL, " ");
			int i = atoi(tok);

			tok = strtok(NULL, " ");
			int j = atoi(tok);

			tok = strtok(NULL, " ");
			bool k;

			if (!strcmp(cut_tok(tok), "true")) {
				k = true;
			}
			else k = false;

			size_t m = bitmap_scan_and_flip(b_pointer, i, j, k);

			printf("%zu\n", m);
		}

		else if (!strcmp(tok, "bitmap_set")) {
			tok = strtok(NULL, " ");
			b_pointer = find_bitmap(tok);

			tok = strtok(NULL, " ");
			int i = atoi(tok);

			tok = strtok(NULL, " ");
			bool k;

			if (!strcmp(cut_tok(tok), "true")) {
				k = true;
			}
			else k = false;

			bitmap_set(b_pointer, i, k);
		}

		else if (!strcmp(tok, "bitmap_set_multiple")) {
			tok = strtok(NULL, " ");
			b_pointer = find_bitmap(tok);

			tok = strtok(NULL, " ");
			int i = atoi(tok);

			tok = strtok(NULL, " ");
			int j = atoi(tok);

			tok = strtok(NULL, " ");
			bool k;

			if (!strcmp(cut_tok(tok), "true")) {
				k = true;
			}
			else k = false;

			bitmap_set_multiple(b_pointer, i, j, k);
		}

		else if (!strcmp(tok, "bitmap_set_all")) {
			tok = strtok(NULL, " ");
			b_pointer = find_bitmap(tok);

			tok = strtok(NULL, " ");
			bool k;

			if (!strcmp(cut_tok(tok), "true")) {
				k = true;
			}
			else k = false;

			bitmap_set_all(b_pointer, k);
		}

		else if (!strcmp(tok, "bitmap_size")) {
			tok = strtok(NULL, " ");
			b_pointer = find_bitmap(tok);

			printf("%zu\n", bitmap_size(b_pointer));
		}

		else if (!strcmp(tok, "bitmap_test")) {
			tok = strtok(NULL, " ");
			b_pointer = find_bitmap(tok);

			tok = strtok(NULL, " ");
			int i = atoi(tok);

			if (bitmap_test(b_pointer, i)) {
				printf("true\n");
			}
			else printf("false\n");
		}
	}
	return 0;
}

char* cut_tok(char* tok) {
	//char* tok_temp;
	char tok2[MAX];
	char* tok2_temp;
	int len_tok2;

	tok2_temp = tok;
	strcpy(tok2, tok);

	// tok_temp�� tok_temp2�� ������ ���ڸ� ����Ŵ
	len_tok2 = strlen(tok2);
	tok2_temp = tok2 + len_tok2;
	tok2_temp--;

	// tok_temp ���� �ִ� �����̳� ��, ���๮�ڸ� �����ش�.
	while ((tok2_temp != tok2) && (isspace(*tok2_temp))) {
		tok2_temp--;
	}
	tok2_temp++;
	*tok2_temp = '\0';
	
	tok = tok2;

	return tok;

}

bool l_less_func(const struct list_elem* a, const struct list_elem* b, void* aux) {
	struct list_item* list_1 = list_entry(a, struct list_item, elem);
	struct list_item* list_2 = list_entry(b, struct list_item, elem);

	if ((list_1->data) < (list_2->data)) {
		return true;
	}
	else return false;
}

bool h_less_func(const struct hash_elem* a, const struct hash_elem* b, void* aux) {
	struct hash_item* hash_1 = hash_entry(a, struct hash_item, elem);
	struct hash_item* hash_2 = hash_entry(b, struct hash_item, elem);

	if ((hash_1->data) < (hash_2->data)) {
		return true;
	}
	else return false;

}

unsigned int h_hash_func(const struct hash_elem* a, void* aux) {
	h_item = hash_entry(a, struct hash_item, elem);
	return hash_int(h_item->data);
}

struct list* find_list(char* name) {
	name = cut_tok(name);
	for (int i = 0; i < MAX; i++) {
		if (!strcmp(list_[i].list_name, name)) {
			return &list_[i];
		}
	}
}

struct hash* find_hash(char* name) {
	name = cut_tok(name);
	for (int i = 0; i < MAX; i++) {
		if (!strcmp(hash_[i].hash_name, name)) {
			h_idx2 = i;
			return &hash_[i];
		}
	}
}

struct bitmap* find_bitmap(char* name) {
	char bitmap_name_temp[20];
	strcpy(bitmap_name_temp, cut_tok(name));
	for (int i = 0; i < MAX; i++) {
		if ((b_idx_arr[i] != 0) && !(strcmp(b_name_return(bitmap_[i]), bitmap_name_temp))) {
			b_idx = i;
			return bitmap_[i];
		}
	}
}

void h_ac(struct hash_elem* a, void* aux) {
	struct list_elem l_e = a->list_elem;
	struct list_elem* l_e_pointer = l_e.prev;
	struct hash_item* h_i = hash_entry(a, struct hash_item, elem);

	l_e.prev->next = l_e.next;
	l_e.next->prev = l_e_pointer;

	free(h_i);
}

void h_square(struct hash_elem* a, void* aux) {
	struct hash_item* h_i_ptr = malloc(sizeof(struct hash_item));
	h_i_ptr = hash_entry(a, struct hash_item, elem);
	int i = h_i_ptr->data;
	i = i * i;
	h_i_ptr->data = i;
}

void h_triple(struct hash_elem* a, void* aux) {
	struct hash_item* h_i_ptr = malloc(sizeof(struct hash_item));
	h_i_ptr = hash_entry(a, struct hash_item, elem);
	int i = h_i_ptr->data;
	i = i * i * i;
	h_i_ptr->data = i;
}
