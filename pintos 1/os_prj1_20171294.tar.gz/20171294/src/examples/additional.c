#include <stdio.h>
#include <stdlib.h>
#include <syscall.h>

int main (int argc, char **argv) {
  int n1, n2, n3, n4;

  if (argc != 5) return EXIT_FAILURE;

  else {
	  n1 = atoi(argv[1]);
	  n2 = atoi(argv[2]);
	  n3 = atoi(argv[3]);
	  n4 = atoi(argv[4]);
	  printf("%d %d\n", fibonacci(n1), max_of_four_int(n1, n2, n3, n4));

	  return EXIT_SUCCESS;
  }
}

