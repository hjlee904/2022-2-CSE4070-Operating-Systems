#include "userprog/syscall.h"
#include <stdio.h>
#include <syscall-nr.h>
#include "threads/interrupt.h"
#include "threads/thread.h"
#include "threads/vaddr.h"

static void syscall_handler (struct intr_frame *);

void
syscall_init (void) 
{
  intr_register_int (0x30, 3, INTR_ON, syscall_handler, "syscall");
}

static void
syscall_handler (struct intr_frame *f UNUSED) 
{ 
  switch (*(uint32_t*)(f->esp)) {
  case SYS_HALT:
	  halt();
	  break;
  case SYS_EXIT:
	  if (!is_user_vaddr(f->esp + 4)) { exit(-1); }
	  exit(*(uint32_t*)(f->esp + 4));
	  break;
  case SYS_EXEC:
	  if (!is_user_vaddr(f->esp + 4)) { exit(-1); }
	  f->eax = exec(*(char**)(f->esp + 4));
	  break;
  case SYS_WAIT:
	  if (!is_user_vaddr(f->esp + 4)) { exit(-1); }
	  f->eax = wait(*(int*)(f->esp + 4));
	  break;
  case SYS_READ:
	  f->eax = read((int)*(uint32_t*)(f->esp + 4),
		  (void*)*(uint32_t*)(f->esp + 8),
		  (unsigned)*(uint32_t*)(f->esp + 12));
	  break;
  case SYS_WRITE:
	  f->eax = write((int)*(uint32_t*)(f->esp + 4),
		  (void*)*(uint32_t*)(f->esp + 8),
		  (unsigned)*(uint32_t*)(f->esp + 12));
	  break;
  case SYS_FIBONACCI:
	  f->eax = fibonacci((int)*(uint32_t*)(f->esp + 4));
	  break;
  case SYS_MAX_OF_FOUR_INT:
	  f->eax = max_of_four_int((int)*(uint32_t*)(f->esp + 4),
		  (int)*(uint32_t*)(f->esp + 8),
		  (int)*(uint32_t*)(f->esp + 12),
		  (int)*(uint32_t*)(f->esp + 16));
  }
}

void halt(void) {
	shutdown_power_off();
}

void exit(int st) {
	struct thread* c_thr = thread_current();
	int p_tid = c_thr->p_tid;
	struct thread* p_thr = thr_find(p_tid);

	p_thr->c_st = st;
	printf("%s: exit(%d)\n", c_thr->name, st);

	thread_exit();
}

pid_t exec(const char* cmd) {
	return process_execute(cmd);
}

int wait(pid_t pid) {
	return process_wait(pid);
}

int read(int fd, void* buf, unsigned size) {
	void* t_buf = buf;
	int sz = (int)size;
	int i = 0;

	if (fd == 0) {
		for (i = 0; i < sz; i++) {
			*(uint8_t*)t_buf = input_getc();
			if (*(uint8_t*)t_buf++ == '\0') {
				break;
			}
		}
		return i;
	}

	return -1;
}

int write(int fd, const void* buf, unsigned size) {
	if (fd == 1) {
		putbuf(buf, size);
		return size;
	}

	return -1;
}

int fibonacci(int n) {
	int fib0 = 0;
	int fib1 = 1;
	int tmp;

	for (int i = 1; i < n; i++) {
		tmp = fib1;
		fib1 += fib0;
		fib0 = tmp;
	}

	return fib1;
}

int max_of_four_int(int a, int b, int c, int d) {
	int tmp = a;

	if (tmp < b) { tmp = b; }
	if (tmp < c) { tmp = c; }
	if (tmp < d) { tmp = d; }

	return tmp;
}
