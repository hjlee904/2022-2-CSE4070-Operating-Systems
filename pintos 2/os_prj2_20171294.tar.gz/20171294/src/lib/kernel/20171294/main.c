#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <ctype.h>
#include "list.h"
#include "hash.h"
#include "bitmap.h"

#define MAX_SIZE 20

struct list list_arr[MAX_SIZE];
struct list* list_ptr;
struct list_elem* list_elem_ptr;
struct list_item* list_item_ptr;

struct hash hash_arr[MAX_SIZE];
struct hash* hash_ptr;
struct hash_elem* hash_elem_ptr;
struct hash_item* hash_item_ptr;

struct bitmap* bitmap_arr[MAX_SIZE];
struct bitmap* bitmap_ptr;

/* List: create list, dumpdata, delete, list_back, list_front, list_empty, list_insert, list_insert_ordered,
list_max, list_min, list_pop_back, list_pop_front, list_push_back, list_push_front, list_remove, list_reverse, 
list_shuffle, list_size, list_sort, list_splice, list_swap, list_unique. */

/* Hashtable: create hashtable, dumpdata, delete, hash_apply, hash_clear, hash_delete, hash_empty, 
hash_find, hash_insert, hash_size, hash_replace. */

/* Bitmap: create bitmap, dumpdata, delete, bitmap_all, bitmap_any, bitmap_contains, bitmap_count, 
bitmap_dump, bitmap_expand, bitmap_flip, bitmap_mark, bitmap_none, bitmap_reset, bitmap_scan, 
bitmap_scan_and_flip, bitmap_set, bitmap_set_all, bitmap_set_multiple, bitmap_size, bitmap_test. */

int n1 = 0, n2 = 0, i2 = 0;
int n3;
int bitmap_n3[MAX_SIZE] = { 0 };
struct list list_t[MAX_SIZE];
struct hash hash_t[MAX_SIZE];
struct bitmap* bitmap_t[MAX_SIZE];

/* token�� ������ �Լ�. */
char* ctoken(char* token) {
    char* token_;
    char temp[MAX_SIZE];
    token_ = token;
    strcpy(temp, token);

    while (*token_ != '\0') {
        if (isspace(*token_)) token_++;
        else {
            token = token_; break;
        }
    }
    token_ = temp + strlen(temp) - 1;
    while ((isspace(*token_)) && (token_ != temp)) token_--;
    *(token_ + 1) = '\0';
    token = temp;

    return token;
}

/* �̸��� ��ġ�ϴ� list�� ã�´�. */
struct list* list_matched(char* name_) {
    name_ = ctoken(name_);
    for (int i = 0; i < MAX_SIZE; i++) {
        if (!strcmp(list_t[i].name, name_)) return &list_t[i];
    }
}
/* �̸��� ��ġ�ϴ� hashtable�� ã�´�. */
struct hash* hash_matched(char* name_) {
    name_ = ctoken(name_);
    for (int i = 0; i < MAX_SIZE; i++) {
        if (!strcmp(hash_t[i].name, name_)) {
            i2 = i;
            return &hash_t[i];
        }
    }
}
/* �̸��� ��ġ�ϴ� bitmap�� ã�´�. */
struct bitmap* bitmap_matched(char* name_) {
    char name[10];
    strcpy(name, ctoken(name_));
    for (int i = 0; i < MAX_SIZE; i++) {
        if (bitmap_n3[i] != 0 && !strcmp(bitmap_f1(bitmap_t[i]), name)) {
            n3 = i;
            return bitmap_t[i];
        }
    }
}

/* List�� data�� ��Ұ��踦 ���ϰ� a�� data�� ���� b�� data�� ������ ������ true, �׷��� ������ false�� return. */
bool list_less(const struct list_elem* a, const struct list_elem* b, void* aux) {
    struct list_item* list_item_a = list_entry(a, struct list_item, elem);
    struct list_item* list_item_b = list_entry(b, struct list_item, elem);

    if (list_item_a->data < list_item_b->data) {
        return true;
    }
    else return false;
};

/* hash_apply�� hash_clear���� ���. */
void dest(struct hash_elem* e, void* aux) {
    struct hash_item* temp_hash_item = hash_entry(e, struct hash_item, elem);
    struct list_elem temp_list_elem = e->list_elem;
    struct list_elem* temp_list_elem_ptr = temp_list_elem.prev;

    temp_list_elem.prev->next = temp_list_elem.next;
    temp_list_elem.next->prev = temp_list_elem_ptr;

    free(temp_hash_item);
}

/* Bitmap�� ����� ���� ��� ������ index�� ã�´�. */
int bitmap_find_index() {
    for (int i = 0; i < MAX_SIZE; i++) {
        if (bitmap_n3[i] == 0) return i;
    }
}

int main() {
    char str[50];
    int k = 0;

    /* quit�� �Էµ� ������ �ݺ��Ѵ�. */
    while (1) {
        fgets(str, sizeof(str), stdin);

        /* quit: ����. */
        if (!strcmp(str, "quit\n")) break;

        char* token = strtok(str, " ");

        /* Create list/hashtable/bitmap. */
        if (!strcmp(token, "create")) {
            token = strtok(NULL, " ");

            /* Create list */
            if (!strcmp(token, "list")) {
                list_ptr = &list_t[n1];
                list_init(list_ptr);

                token = strtok(NULL, " ");
                strcpy(list_ptr->name, ctoken(token));
                n1++;
            }

            /* Create hashtable. */
            else if (!strcmp(token, "hashtable")) {
                hash_ptr = &hash_t[n2];
                /* Hashtable�� data�� ��Ұ��踦 ���ϰ� a�� data�� ���� b�� data�� ������ ������ true, �ƴϸ� false�� return. */
                bool hash_less(const struct hash_elem* a, const struct hash_elem* b, void* aux) {
                    struct hash_item* hash_item_a = hash_entry(a, struct hash_item, elem);
                    struct hash_item* hash_item_b = hash_entry(b, struct hash_item, elem);

                    if (hash_item_a->data < hash_item_b->data) {
                        return true;
                    }
                    else return false;
                };
                /* hash�Լ� ����. */
                unsigned int hash_hash(const struct hash_elem* e, void* aux) {
                    hash_item_ptr = hash_entry(e, struct hash_item, elem);
                    return hash_int(hash_item_ptr->data);
                };

                hash_init(hash_ptr, hash_hash, hash_less, NULL);

                for (int i = 0; i < hash_ptr->bucket_cnt; i++) {
                    list_init(&hash_ptr->buckets[i]);
                }

                token = strtok(NULL, " ");
                strcpy(hash_ptr->name, ctoken(token));
                n2++;
            }

            /* Create bitmap. */
            else if (!strcmp(token, "bitmap")) {
                int i = bitmap_find_index();
                bitmap_n3[i] = 1;

                token = strtok(NULL, " ");
                char temp_name[10];
                strcpy(temp_name, ctoken(token));

                token = strtok(NULL, " ");
                size_t size = atoi(token);
                bitmap_t[i] = bitmap_create(size);
                bitmap_f2(bitmap_t[i], temp_name);
            }
        }

        /* Dumptdata�� �Էµ��� ��. testlib�� data�� ����. */
        else if (!strcmp(token, "dumpdata")) {
            token = strtok(NULL, " ");
            int i = 0;

            /* Dumpdata list. */
            if (strstr(token, "list") != NULL) {
                list_ptr = list_matched(token);
                list_elem_ptr = list_begin(list_ptr);

                while (list_tail(list_ptr) != list_elem_ptr) {
                    i = 1;
                    list_item_ptr = list_entry(list_elem_ptr, struct list_item, elem);
                    printf("%d ", list_item_ptr->data);
                    list_elem_ptr = list_next(list_elem_ptr);
                }
            }

            /* Dumpdata hash. */
            else if (strstr(token, "hash") != NULL) {
                int i = 0;
                struct hash_iterator itr;
                hash_ptr = hash_matched(token);
                hash_first(&itr, hash_ptr);

                while (hash_next(&itr)) {
                    i = 1;
                    hash_item_ptr = hash_entry(hash_cur(&itr), struct hash_item, elem);
                    printf("%d ", hash_item_ptr->data);
                }
                if (i)
                    printf("\n");
            }

            /* Dumpdata bm. */
            else if (strstr(token, "bm") != NULL) {
                bitmap_ptr = bitmap_matched(token);
                bitmap_dp(bitmap_ptr);
            }
            if (i)
                printf("\n");
        }

        /* Delete list/hashtable/bitmap. */
        else if (!strcmp(token, "delete")) {
            token = strtok(NULL, " ");

            /* Delete list. */
            if (list_ptr != NULL) {
                list_ptr = list_matched(token);
                list_elem_ptr = list_begin(list_ptr);

                while (list_elem_ptr != list_tail(list_ptr)) {
                    list_item_ptr = list_entry(list_elem_ptr, struct list_item, elem);
                    list_elem_ptr = list_next(list_elem_ptr);
                    free(list_item_ptr);
                }
                list_init(list_ptr);
            }

            /* Delete hash. */
            else if (hash_ptr != NULL) {
                hash_ptr = hash_matched(token);
                hash_destroy(hash_ptr, *dest);
                hash_init(&hash_t[i2], NULL, NULL, NULL);
            }

            /* Delete bm. */
            else if (bitmap_ptr != NULL) {
                bitmap_ptr = bitmap_matched(token);
                bitmap_destroy(bitmap_ptr);
                bitmap_t[n3] = NULL;
                bitmap_n3[n3] = 0;
            }
        }

        /* List functions. */
        /* list_back */
        else if (!strcmp(token, "list_back")) {
            token = strtok(NULL, " ");
            list_elem_ptr = list_rbegin(list_matched(token));
            list_item_ptr = list_entry(list_elem_ptr, struct list_item, elem);
            printf("%d\n", list_item_ptr->data);
        }

        /* list_front */
        else if (!strcmp(token, "list_front")) {
            token = strtok(NULL, " ");
            list_elem_ptr = list_begin(list_matched(token));
            list_item_ptr = list_entry(list_elem_ptr, struct list_item, elem);
            printf("%d\n", list_item_ptr->data);
        }

        /* list_empty */
        else if (!strcmp(token, "list_empty")) {
            token = strtok(NULL, " ");
            list_ptr = list_matched(token);
            if (list_empty(list_ptr)) printf("true\n");
        else printf("false\n");
        }

        /* list_insert */
        else if (!strcmp(token, "list_insert")) {
            token = strtok(NULL, " ");
            list_ptr = list_matched(token);

            token = strtok(NULL, " ");
            k = atoi(token);

            list_elem_ptr = malloc(sizeof(struct list_elem));
            list_item_ptr = malloc(sizeof(struct list_item));
            list_item_ptr = list_entry(list_elem_ptr, struct list_item, elem);

            token = strtok(NULL, " ");
            list_item_ptr->data = atoi(token);

            struct list_elem* list_elem_ptr2 = list_begin(list_ptr);
            int k2 = 0;
            while (k2 < k) {
                list_elem_ptr2 = list_next(list_elem_ptr2);
                k2++;
            }
            list_insert(list_elem_ptr2, list_elem_ptr);
        }

        /* list_insert_ordered */
        else if (!strcmp(token, "list_insert_ordered")) {
            token = strtok(NULL, " ");
            list_ptr = list_matched(token);
            list_elem_ptr = malloc(sizeof(struct list_elem));
            list_item_ptr = malloc(sizeof(struct list_item));
            list_item_ptr = list_entry(list_elem_ptr, struct list_item, elem);

            token = strtok(NULL, " ");
            list_item_ptr->data = atoi(token);

            list_insert_ordered(list_ptr, list_elem_ptr, *list_less, NULL);
        }

        /* list_max */
        else if (!strcmp(token, "list_max")) {
            token = strtok(NULL, " ");
            list_ptr = list_matched(token);
            list_elem_ptr = list_max(list_ptr, *list_less, NULL);
            list_item_ptr = list_entry(list_elem_ptr, struct list_item, elem);
            printf("%d\n", list_item_ptr->data);
        }

        /* list_min */
        else if (!strcmp(token, "list_min")) {
            token = strtok(NULL, " ");
            list_ptr = list_matched(token);
            list_elem_ptr = list_min(list_ptr, *list_less, NULL);
            list_item_ptr = list_entry(list_elem_ptr, struct list_item, elem);
            printf("%d\n", list_item_ptr->data);
        }

        /* list_pop_back */
        else if (!strcmp(token, "list_pop_back")) {
            token = strtok(NULL, " ");
            list_ptr = list_matched(token);
            list_elem_ptr = list_pop_back(list_ptr);
        }

        /* list_pop_front */
        else if (!strcmp(token, "list_pop_front")) {
            token = strtok(NULL, " ");
            list_ptr = list_matched(token);
            list_elem_ptr = list_pop_front(list_ptr);
        }

        /* list_push_back */
        else if (!strcmp(token, "list_push_back")) {
            token = strtok(NULL, " ");
            list_ptr = list_matched(token);
            list_elem_ptr = malloc(sizeof(struct list_elem));
            list_item_ptr = malloc(sizeof(struct list_item));
            list_item_ptr = list_entry(list_elem_ptr, struct list_item, elem);

            token = strtok(NULL, " ");
            list_item_ptr->data = atoi(token);

            list_push_back(list_ptr, list_elem_ptr);
        }

        /* list_push_front */
        else if (!strcmp(token, "list_push_front")) {
            token = strtok(NULL, " ");
            list_ptr = list_matched(token);
            list_elem_ptr = malloc(sizeof(struct list_elem));
            list_item_ptr = malloc(sizeof(struct list_item));
            list_item_ptr = list_entry(list_elem_ptr, struct list_item, elem);

            token = strtok(NULL, " ");
            list_item_ptr->data = atoi(token);

            list_push_front(list_ptr, list_elem_ptr);
        }

        /* list_remove */
        else if (!strcmp(token, "list_remove")) {
            token = strtok(NULL, " ");
            list_elem_ptr = list_begin(list_matched(token));

            k = 0;
            token = strtok(NULL, " ");
            while (k < atoi(token)) {
                list_elem_ptr = list_next(list_elem_ptr);
                k++;
            }
            list_remove(list_elem_ptr);
        }

        /* list_reverse */
        else if (!strcmp(token, "list_reverse")) {
            token = strtok(NULL, " ");
            list_ptr = list_matched(token);
            list_reverse(list_ptr);
        }

        /* list_shuffle */
        else if (!strcmp(token, "list_shuffle")) {
            token = strtok(NULL, " ");
            list_ptr = list_matched(token);
            list_shuffle(list_ptr);
        }

        /* list_size */
        else if (!strcmp(token, "list_size")) {
            token = strtok(NULL, " ");
            list_ptr = list_matched(token);
            printf("%zu\n", list_size(list_ptr));
        }

        /* list_sort */
        else if (!strcmp(token, "list_sort")) {
            token = strtok(NULL, " ");
            list_ptr = list_matched(token);
            list_sort(list_ptr, *list_less, NULL);
        }

        /* list_splice */
        else if (!strcmp(token, "list_splice")) {
            int k1, k2, k3;

            token = strtok(NULL, " ");
            struct list* list_ptr1 = list_matched(token);
            token = strtok(NULL, " ");
            k1 = atoi(token);

            token = strtok(NULL, " ");
            struct list* list_ptr2 = list_matched(token);
            token = strtok(NULL, " ");
            k2 = atoi(token);
            token = strtok(NULL, " ");
            k3 = atoi(token);

            struct list_elem* list_elem_before = list_begin(list_ptr1);
            struct list_elem* list_elem_first = list_begin(list_ptr2);
            struct list_elem* list_elem_last = list_begin(list_ptr2);

            k = 0;
            while (k < k1) {
                list_elem_before = list_next(list_elem_before);
                k++;
            }
            k = 0;
            while (k < k2) {
                list_elem_first = list_next(list_elem_first);
                k++;
            }
            k = 0;
            while (k < k3) {
                list_elem_last = list_next(list_elem_last);
                k++;
            }

            list_splice(list_elem_before, list_elem_first, list_elem_last);
        }

        /* list_swap */
        else if (!strcmp(token, "list_swap")) {
            int k1, k2;
            token = strtok(NULL, " ");
            list_ptr = list_matched(token);

            token = strtok(NULL, " ");
            k1 = atoi(token);
            token = strtok(NULL, " ");
            k2 = atoi(token);

            struct list_elem* list_elem_ptr1 = list_begin(list_ptr);
            struct list_elem* list_elem_ptr2 = list_begin(list_ptr);

            k = 0;
            while (k < k1) {
                list_elem_ptr1 = list_next(list_elem_ptr1);
                k++;
            }
            k = 0;
            while (k < k2) {
                list_elem_ptr2 = list_next(list_elem_ptr2);
                k++;
            }

            list_swap(list_elem_ptr1, list_elem_ptr2);
        }
       
        /* list_unique */
        else if (!strcmp(token, "list_unique")) {
            token = strtok(NULL, " ");
            list_ptr = list_matched(token);
            token = strtok(NULL, " ");
            struct list* list_ptr_duplicate;

            if (token != NULL) {
                list_ptr_duplicate = list_matched(token);
            }
            else {
                list_ptr_duplicate = malloc(sizeof(struct list));
                list_init(list_ptr_duplicate);
            }

            list_unique(list_ptr, list_ptr_duplicate, *list_less, NULL);
        }
        
        /* Hashtable functions. */
        /* hash_apply */
        else if (!strcmp(token, "hash_apply")) {
            token = strtok(NULL, " ");
            hash_ptr = hash_matched(token);

            token = strtok(NULL, "\n");
            if (!strcmp(token, "square")) hash_apply(hash_ptr, *square_func);
            else if (!strcmp(token, "triple")) hash_apply(hash_ptr, *triple_func);
        }

        /* hash_clear */
        else if (!strcmp(token, "hash_clear")) {
            token = strtok(NULL, " ");
            hash_ptr = hash_matched(token);
            hash_clear(hash_ptr, *dest);
        }

        /* hash_delete */
        else if (!strcmp(token, "hash_delete")) {
            token = strtok(NULL, " ");
            hash_ptr = hash_matched(token);
            hash_elem_ptr = malloc(sizeof(struct hash_elem));
            hash_item_ptr = malloc(sizeof(struct hash_item));
            hash_item_ptr = hash_entry(hash_elem_ptr, struct hash_item, elem);

            token = strtok(NULL, " ");
            hash_item_ptr->data = atoi(token);

            hash_delete(hash_ptr, hash_elem_ptr);
        }

        /* hash_empty */
        else if (!strcmp(token, "hash_empty")) {
            token = strtok(NULL, " ");
            hash_ptr = hash_matched(token);

            if (hash_empty(hash_ptr)) printf("true\n");
            else printf("false\n");
        }

        /* hash_find */
        else if (!strcmp(token, "hash_find")) {
            token = strtok(NULL, " ");
            hash_ptr = hash_matched(token);
            hash_elem_ptr = malloc(sizeof(struct hash_elem));
            hash_item_ptr = malloc(sizeof(struct hash_item));
            hash_item_ptr = hash_entry(hash_elem_ptr, struct hash_item, elem);

            token = strtok(NULL, " ");
            hash_item_ptr->data = atoi(token);

            if (hash_find(hash_ptr, hash_elem_ptr) != NULL) printf("%d\n", hash_item_ptr->data);
        }

        /* hash_insert */
        else if (!strcmp(token, "hash_insert")) {
            token = strtok(NULL, " ");
            hash_ptr = hash_matched(token);
            hash_elem_ptr = malloc(sizeof(struct hash_elem));
            hash_item_ptr = malloc(sizeof(struct hash_item));
            hash_item_ptr = hash_entry(hash_elem_ptr, struct hash_item, elem);

            token = strtok(NULL, " ");
            hash_item_ptr->data = atoi(token);

            hash_insert(hash_ptr, hash_elem_ptr);
        }
       
        /* hash_size */
        else if (!strcmp(token, "hash_size")) {
            token = strtok(NULL, " ");
            hash_ptr = hash_matched(token);
            printf("%zu\n", hash_size(hash_ptr));
        }

        /* hash_replace */
        else if (!strcmp(token, "hash_replace")) {
            token = strtok(NULL, " ");
            hash_ptr = hash_matched(token);
            hash_elem_ptr = malloc(sizeof(struct hash_elem));
            hash_item_ptr = malloc(sizeof(struct hash_item));
            hash_item_ptr = hash_entry(hash_elem_ptr, struct hash_item, elem);

            token = strtok(NULL, " ");
            hash_item_ptr->data = atoi(token);

            hash_replace(hash_ptr, hash_elem_ptr);
        }
        
        /* Bitmap functions. */
        /* bitmap_all */
        else if (!strcmp(token, "bitmap_all")) {
            token = strtok(NULL, " ");
            bitmap_ptr = bitmap_matched(token);

            token = strtok(NULL, " ");
            size_t start_idx = atoi(token);
            token = strtok(NULL, " ");
            size_t cnt = atoi(token);

            printf("%s\n", bitmap_all(bitmap_ptr, start_idx, cnt) ? "true" : "false");
        }

        /* bitmap_any */
        else if (!strcmp(token, "bitmap_any")) {
            token = strtok(NULL, " ");
            bitmap_ptr = bitmap_matched(token);

            token = strtok(NULL, " ");
            size_t start_idx = atoi(token);
            token = strtok(NULL, " ");
            size_t cnt = atoi(token);

            printf("%s\n", bitmap_any(bitmap_ptr, start_idx, cnt) ? "true" : "false");
        }

        /* bitmap_contains */
        else if (!strcmp(token, "bitmap_contains")) {
            token = strtok(NULL, " ");
            bitmap_ptr = bitmap_matched(token);

            token = strtok(NULL, " ");
            size_t start_idx = atoi(token);
            token = strtok(NULL, " ");
            size_t cnt = atoi(token);

            token = strtok(NULL, " ");
            bool value = strcmp(ctoken(token), "true") ? false : true;

            printf("%s\n", bitmap_contains(bitmap_ptr, start_idx, cnt, value) ? "true" : "false");
        }

        /* bitmap_count */
        else if (!strcmp(token, "bitmap_count")) {
            token = strtok(NULL, " ");
            bitmap_ptr = bitmap_matched(token);

            token = strtok(NULL, " ");
            size_t start_idx = atoi(token);
            token = strtok(NULL, " ");
            size_t cnt = atoi(token);

            token = strtok(NULL, " ");
            bool value = strcmp(ctoken(token), "true") ? false : true;

            printf("%zu\n", bitmap_count(bitmap_ptr, start_idx, cnt, value));
        }

        /* bitmap_dump*/
        else if (!strcmp(token, "bitmap_dump")) {
            token = strtok(NULL, " ");
            bitmap_ptr = bitmap_matched(token);
            bitmap_dump(bitmap_ptr);
        }

        /* bitmap_expand*/
        else if (!strcmp(token, "bitmap_expand")) {
            token = strtok(NULL, " ");
            bitmap_ptr = bitmap_matched(token);

            token = strtok(NULL, " ");
            k = atoi(token);

            bitmap_expand(bitmap_ptr, k);
        }

        /* bitmap_flip */
        else if (!strcmp(token, "bitmap_flip")) {
            token = strtok(NULL, " ");
            bitmap_ptr = bitmap_matched(token);

            token = strtok(NULL, " ");
            size_t flip_idx = atoi(token);

            bitmap_flip(bitmap_ptr, flip_idx);
        }

        /* bitmap_mark */
        else if (!strcmp(token, "bitmap_mark")) {
            token = strtok(NULL, " ");
            bitmap_ptr = bitmap_matched(token);

            token = strtok(NULL, " ");
            k = atoi(token);

            bitmap_mark(bitmap_ptr, k);
        }

        /* bitmap_none */
        else if (!strcmp(token, "bitmap_none")) {
            token = strtok(NULL, " ");
            bitmap_ptr = bitmap_matched(token);

            token = strtok(NULL, " ");
            size_t start_idx = atoi(token);
            token = strtok(NULL, " ");
            size_t cnt = atoi(token);

            printf("%s\n", bitmap_none(bitmap_ptr, start_idx, cnt) ? "true" : "false");
        }

        /* bitmap_reset */
        else if (!strcmp(token, "bitmap_reset")) {
            token = strtok(NULL, " ");
            bitmap_ptr = bitmap_matched(token);

            token = strtok(NULL, " ");
            k = atoi(token);

            bitmap_reset(bitmap_ptr, k);
        }

        /* bitmap_scan */
        else if (!strcmp(token, "bitmap_scan")) {
            token = strtok(NULL, " ");
            bitmap_ptr = bitmap_matched(token);

            token = strtok(NULL, " ");
            size_t start_idx = atoi(token);
            token = strtok(NULL, " ");
            size_t cnt = atoi(token);

            token = strtok(NULL, " ");
            bool value = strcmp(ctoken(token), "true") ? false : true;

            size_t tmp_idx = bitmap_scan(bitmap_ptr, start_idx, cnt, value);
            printf("%zu\n", tmp_idx);
        }

        /* bitmap_scan_and_flip*/
        else if (!strcmp(token, "bitmap_scan_and_flip")) {
            token = strtok(NULL, " ");
            bitmap_ptr = bitmap_matched(token);

            token = strtok(NULL, " ");
            size_t start_idx = atoi(token);
            token = strtok(NULL, " ");
            size_t cnt = atoi(token);

            token = strtok(NULL, " ");
            bool value = strcmp(ctoken(token), "true") ? false : true;

            size_t tmp_idx = bitmap_scan_and_flip(bitmap_ptr, start_idx, cnt, value);
            printf("%zu\n", tmp_idx);
        }
        
        /* bitmap_set */
        else if (!strcmp(token, "bitmap_set")) {
            token = strtok(NULL, " ");
            bitmap_ptr = bitmap_matched(token);

            token = strtok(NULL, " ");
            size_t idx = atoi(token);

            token = strtok(NULL, " ");
            bool value = strcmp(ctoken(token), "true") ? false : true;

            bitmap_set(bitmap_ptr, idx, value);
        }
        
        /* bitmap_set_all */
        else if (!strcmp(token, "bitmap_set_all")) {
            token = strtok(NULL, " ");
            bitmap_ptr = bitmap_matched(token);

            token = strtok(NULL, " ");
            bool value = strcmp(ctoken(token), "true") ? false : true;

            bitmap_set_all(bitmap_ptr, value);
        }

        /* bitmap_set_multiple */
        else if (!strcmp(token, "bitmap_set_multiple")) {
            token = strtok(NULL, " ");
            bitmap_ptr = bitmap_matched(token);

            token = strtok(NULL, " ");
            size_t start_idx = atoi(token);
            token = strtok(NULL, " ");
            size_t cnt = atoi(token);

            token = strtok(NULL, " ");
            bool value = strcmp(ctoken(token), "true") ? false : true;

            bitmap_set_multiple(bitmap_ptr, start_idx, cnt, value);
        }

        /* bitmap_size */
        else if (!strcmp(token, "bitmap_size")) {
            token = strtok(NULL, " ");
            bitmap_ptr = bitmap_matched(token);
            printf("%zu\n", bitmap_size(bitmap_ptr));
        }

        /* bitmap_test */
        else if (!strcmp(token, "bitmap_test")) {
            token = strtok(NULL, " ");
            bitmap_ptr = bitmap_matched(token);

            token = strtok(NULL, " ");
            size_t idx = atoi(token);

            printf("%s\n", bitmap_test(bitmap_ptr, idx) ? "true" : "false");
        }
    }
    return 0;
}